#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct Aplikasi{
    char name[100];
    char lokasi;
    Aplikasi *next;
    Aplikasi *prev;
}*head, *tail;

Aplikasi *buatAplikasi(char name[], char lokasi){
    Aplikasi *newApp = (Aplikasi *)malloc(sizeof(Aplikasi));
    strcpy(newApp->name, name);
    newApp->lokasi = lokasi;
    newApp->next = newApp->prev = NULL;
    return newApp;
}

void inputHead(char name[], char lokasi){
    Aplikasi *newApp = buatAplikasi(name,lokasi);
    if(head==NULL){
        head = tail = newApp;
    }
    else{ 
        newApp->next = head;  
        head->prev = newApp;
        head = newApp;
    }
}

void inputTail(char name[], char lokasi){
    Aplikasi *newApp = buatAplikasi(name,lokasi);
    if(tail==NULL){
        head = tail = newApp;
    }
    else{
        tail->next = newApp;
        newApp->prev = tail;
        tail = newApp;
    }
}

void inputMid(char name[], char lokasi){
    Aplikasi *newApp = buatAplikasi(name, lokasi);
    if(head==NULL){
        head = tail = newApp;
    }
    else if(head==tail){
        free(head);
        head = tail = NULL;
    }
    else if(head->lokasi < newApp->lokasi){
        inputHead(name,lokasi);
    }
    else if(tail->lokasi > newApp->lokasi){
        inputTail(name, lokasi);
    }
    else{
        Aplikasi *curr = head;
        while(curr->lokasi > newApp->lokasi){
            curr = curr->next;
        }
        
        newApp->next = curr;
        newApp->prev = curr->prev;
        curr->prev->next = newApp;
        curr->prev = newApp;
    }
}

void freeHead(){
   if(head==NULL){
      return;
   }
   else if(head == tail){
      free(head);
      head=tail=NULL;
   }
   else{
      Aplikasi *newHead = head->next;
      newHead->prev = NULL;
      head->next = NULL;
      free(head);
      head = newHead;
   }
}

void freeTail(){
   if(tail==NULL){
      return;
   }
   else if(head == tail){
      free(tail);
      head=tail=NULL;
   }
   else{
       Aplikasi *newTail = tail->prev;
       newTail->next = NULL;
       tail->prev = NULL;
       free(tail);
       tail = newTail;
   }
}

void freeMid(char hapus[]){
    if(head==NULL){
        return;
    }
    else if(strcmp(head->name,hapus)==0){
        freeHead();
    }
    else if(strcmp(tail->name,hapus)==0){
        freeTail();
    }
    else{
        Aplikasi *curr = head;
        while(curr != NULL && strcmp(curr->name,hapus)!=0){
            curr = curr->next;
        }
        if(curr==NULL){
            return;
        }
        else{
            curr->prev->next = curr->next;
            curr->next->prev = curr->prev;
            curr->next = NULL;
            curr->prev = NULL;
            free(curr);
        }
    }
}

void printLL(){
   Aplikasi *curr = head;
   while(curr != NULL){
      printf("[program: %s | lokasi: %c] <-> ", curr->name, curr->lokasi);
      curr = curr->next;
   }
   printf("NULL\n");
}

int main(){
    Aplikasi m[100];
    int x;
    printf("\nSelamat Datang di Sistem Control Panel\n");
    do{
        printf("\nMenu:\n");
        printf("1. Menambahkan Aplikasi\n");
        printf("2. Menghapus Aplikasi\n");
        printf("3. keluar\n");
        printf("Input menu(1/2/3): ");
        scanf("%d",&x);

        int n;
        if(x==1){
            printf("masukan jumlah data: ");
            scanf("%d",&n);
             printf("Input nama dan lokasi penyimpanan aplikasi dan program hanya bisa menerima lokasi 'C' dan 'D' (contoh: mahi C)\n");
            for(int i=0; i<n; i++){
                printf("%d.input nama dan lokasi: ",i+1);
                scanf("%s %c",m[i].name,&m[i].lokasi);getchar();
                if(strlen(m[i].name)>20 || (m[i].lokasi != 'C' && m[i].lokasi != 'D')){
                    printf("Data ke-%d tidak sesuai format\n", i+1);
                    break;
                }
                else{
                    inputTail(m[i].name,m[i].lokasi);
                }
            }
            printf("Data: ");
            printLL();
        }

        else if(x==2){
            char str[21];
            printf("input nama aplikasi yang ingin dihapus: ");
            scanf("%s",str);getchar();
            printf("Data %s telah dihapus\nData: ",str);
            freeMid(str);
            printf("Data: ");
            printLL();
        }

        else if(x!=1 && x!=2 && x!=3){
            printf("Invalid Input\n");
        }
    }while(x!=3);
    
    printf("Terima kasih telah berkunjung\n");
    
    return 0;
}